﻿#include <windows.h>
#include "MyProgram.h"

LRESULT CALLBACK WndProc(HWND wnd_, UINT msg_, WPARAM wParam_, LPARAM lParam_);
HWND MyProgram_CreateWindow(HINSTANCE inst_, const TCHAR cName_[], const TCHAR tName_[],
	RECT* wSize_, BOOL screenMode_, int showCmd_);

int __stdcall WinMain(HINSTANCE inst_, HINSTANCE, LPSTR, int showCmd)
{
	HWND wnd;//ウィンドウハンドル宣言

	#pragma region ウィンドウ生成

	RECT ws = {//x,y,w,h
		0,	0,
		(int)(gobj.screenState.width * gobj.screenState.viewScale),
		(int)(gobj.screenState.height * gobj.screenState.viewScale)
	};
	wnd = MyProgram_CreateWindow(//ウィンドウハンドルに情報登録
		inst_,
		gobj.windowState.className,
		gobj.windowState.title,
		&ws,
		gobj.screenState.fullScreen,
		showCmd);
	if (wnd == nullptr) { return 0; }//ウィンドウ生成失敗でプログラム終了

	#pragma endregion ウィンドウ生成

	gobj.Initialize(wnd);//環境初期化

	#pragma region メッセージループ

	MSG msg = {};
	while (msg.message != WM_QUIT)
	{
		if (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else if (GetActiveWindow() == wnd)
		{
			gobj.Step(wnd);
		}
	}

	#pragma endregion メッセージループ

	gobj.Finalize();

	return 0;
}

HWND MyProgram_CreateWindow(HINSTANCE inst_, const TCHAR cName_[], const TCHAR
	tName_[],
	RECT* wSize_, BOOL screenMode_, int showCmd_)
{
	WNDCLASSEX wcex; // ウインドウ作成に使用
	HWND wnd; // ウインドウハンドル
	// データ初期化
	wcex.style = (CS_HREDRAW | CS_VREDRAW);
	wcex.hIcon = LoadIcon(inst_, IDI_APPLICATION);
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
	wcex.hIconSm = LoadIcon(inst_, IDI_APPLICATION);
	wcex.hInstance = inst_;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.lpfnWndProc = (WNDPROC)WndProc;
	wcex.lpszMenuName = nullptr;
	wcex.lpszClassName = cName_;
	wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	// Windows に登録
	if (!RegisterClassEx(&wcex))
	{
		MessageBox(nullptr, "ウインドウ登録に失敗", nullptr, MB_OK);
		return nullptr;
	}
	// ウインドウ作成
	DWORD dws = screenMode_ ? WS_POPUP : (WS_CAPTION | WS_SYSMENU);
	AdjustWindowRectEx(wSize_, dws, false, WS_EX_APPWINDOW);
	wnd = CreateWindowEx(WS_EX_APPWINDOW,
		cName_,	tName_,
		dws, 0, 0,
		(wSize_->right - wSize_->left),
		(wSize_->bottom - wSize_->top),
		nullptr, nullptr, inst_, nullptr);
	if (!wnd)
	{
		MessageBox(nullptr, "ウインドウ生成に失敗", nullptr, MB_OK);
		return nullptr;
	}
	ShowWindow(wnd, showCmd_);
	UpdateWindow(wnd);
	return wnd;
}

LRESULT CALLBACK WndProc(HWND wnd_,	UINT msg_, WPARAM wParam_, LPARAM lParam_)
{
	LRESULT ret = (LRESULT)0;

	switch (msg_) {//メッセージハンドラ
	case WM_CREATE://ウィンドウ生成されたとき(開始時のみ)
		break;
	case WM_CLOSE://ウィンドウの✖が押されたとき
		gobj.quitRequest = true;
		break;
	case WM_DESTROY://ウィンドウ破棄されたとき(終了時のみ)
		PostQuitMessage(0);
		break;
	case WM_KEYDOWN:
		if (wParam_ == VK_ESCAPE)
		{
			gobj.quitRequest = true;
		}
	default://それ以外はWindows君に投げつける
		ret = DefWindowProc(wnd_, msg_, wParam_, lParam_);
		break;
	}
	return ret;
}