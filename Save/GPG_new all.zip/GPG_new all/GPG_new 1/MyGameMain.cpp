#include "MyGameMain.h"
DG::Image::SP img;
XI::GamePad::SP in1;
ML::Point pos;
void MyGameMain_Initalize()
{
	{
		XI::AnalogAxisKB ls = { DIK_LEFT, DIK_RIGHT, DIK_UP, DIK_DOWN };
		XI::AnalogAxisKB rs = { 0, 0, 0, 0 };
		XI::AnalogTriggerKB tg = { 0, 0 };
		XI::KeyDatas_KB key = {
		{ DIK_Z, XI::VGP::B1 },{ DIK_X, XI::VGP::B2 },{ DIK_S, XI::VGP::ST },
		};
		XI::KeyDatas_GP but = {
		{ XI::RGP::B01, XI::VGP::B1 },{ XI::RGP::B02, XI::VGP::B2 },
		{ XI::RGP::B08, XI::VGP::ST },
		};
		in1 = XI::GamePad::CreateGP(0, but);
		auto kb = XI::GamePad::CreateKB(ls, rs, tg, key);
		XI::GamePad::Link(in1, kb);
		img = DG::Image::Create("./data/image/Chara00.png");
		pos.x = 0;
		pos.y = 0;
	}
}
void MyGameMain_Finalize()
{
	img.reset();
}
void MyGameMain_Update()
{
	auto inp = in1->GetState();
	if (inp.LStick.BL.on) { pos.x -= 3; }
	if (inp.LStick.BR.on) { pos.x += 3; }
}
void MyGameMain_Render2D()
{
	ML::Box2D draw(0, 0, 64, 32);
	ML::Box2D src(0, 0, 64, 32);
	draw.Offset(pos);
	img->Draw(draw, src);
}