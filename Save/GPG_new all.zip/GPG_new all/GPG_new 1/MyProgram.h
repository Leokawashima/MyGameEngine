#pragma once
#include <fstream>
#include <sstream>
#include <windows.h>
#include <functional>
#pragma comment(lib, "winmm")
#include "XI2018_Ver1_0.h"
#include "DG2014/DG2014_Ver3_6.h"
#include "DM2008_Ver1_4.h"
#include "myLib.h"

class MyGame
{
public:
	DG::DGObject::SP	dgi;
	DM::Obj::SP			dmi;
	XI::Obj::SP			xii;
	struct ScreenState {
		int width;
		int height;
		DWORD multiSample;
		BOOL fullScreen;
		int viewScale;
		int _2DWidth;//���݋@�\���Ă��Ȃ�
		int _2DHeight;//���݋@�\���Ă��Ȃ�
	};
	ScreenState screenState;

	struct WindowsState {
		const char* className;
		const char* title;
	};
	WindowsState windowState;

	bool quitRequest;

	MyGame();
	~MyGame();
	void Step(HWND wnd_);
	BOOL Initialize(HWND wnd_);
	void Finalize();
	void Update();
	void Render2D();
	void Render3D();
};
extern MyGame gobj;