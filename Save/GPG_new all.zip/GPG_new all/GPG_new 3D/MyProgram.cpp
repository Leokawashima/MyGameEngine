#include "MyProgram.h"
#include "MyGameMain.h"
MyGame gobj;

MyGame::MyGame()
{
	this->windowState.className = "GPG_NonGameEnginePG";
	this->windowState.title = "GPG_�Q�[���G���W������";
	this->screenState.width = 480;
	this->screenState.height = 270;
	this->screenState.multiSample = 1;
	this->screenState.viewScale = 2;
	this->screenState.fullScreen = false;

	this->quitRequest = false;

	this->bgColor = ML::Color(1, 1, 1, 1);
}
MyGame::~MyGame()
{
}
void MyGame::Step(HWND wnd_)
{
	this->xii->UpDate();
	this->dmi->UpDate();
	this->Update();
	this->dgi->Begin(ML::Color(1, 0, 1, 0.5f));
	this->Render3D();
	this->Render2D();
	this->dgi->End();

	if (this->quitRequest) {
		MyGameMain_Finalize();
		DestroyWindow(wnd_);
	}
}
BOOL MyGame::Initialize(HWND wnd_)
{
	{
		this->dgi = DG::DGObject::Create(
			wnd_,
			this->screenState.width,
			this->screenState.height,
			this->screenState.multiSample,
			this->screenState.fullScreen,
			this->screenState._2DWidth,
			this->screenState._2DHeight
		);
		if (!this->dgi) {
			DestroyWindow(wnd_);
			return false;
		}
	}
	{
		this->xii = XI::Obj::Create(wnd_);
		if (!this->xii) {
			DestroyWindow(wnd_);
			return false;
		}
	}
	{
		this->dmi = DM::Obj::Create(wnd_);
		if (!this->dmi) {
			DestroyWindow(wnd_);
			return false;
		}
	}
	MyGameMain_Initalize();

	return true;
}
void MyGame::Finalize()
{
	this->dgi.reset();
	this->dmi.reset();
	this->xii.reset();
}
void MyGame::Update()
{
	MyGameMain_Update();
}
void MyGame::Render2D()
{
	this->dgi->Begin2D();
	this->dgi->EffectState().RS_Def2D();
	this->dgi->EffectState().BS_Alpha();

	MyGameMain_Render2D();

	this->dgi->End2D();
}
void MyGame::Render3D()
{
	this->dgi->Begin3D();
	this->dgi->EffectState().BS_Std();

	MyGameMain_Render3D();

	this->dgi->End3D();
}