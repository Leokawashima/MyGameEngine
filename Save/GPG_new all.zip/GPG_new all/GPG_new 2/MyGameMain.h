#pragma once
#include "MyProgram.h"

enum class TaskFlag
{
	Non,
	Title,
	Game,
	Ending,
};
extern void MyGameMain_Initalize();
extern void MyGameMain_Finalize();
extern void MyGameMain_Update();
extern void MyGameMain_Render2D();