#include "MyGameMain.h"

namespace Game
{
	DG::Image::SP imgMapChip;

	void Initialize()
	{
		gobj.bgColor = ML::Color(1, 0, 1, 0);
		imgMapChip = DG::Image::Create("./data/image/MapChip01.bmp");
	}
	void Finalize()
	{
		imgMapChip.reset();
	}
	TaskFlag UpDate()
	{
		auto inp = gobj.in[0]->GetState();
		TaskFlag rtv = TaskFlag::Game;
		if (true == inp.ST.down) {
			rtv = TaskFlag::Title;
		}
		return rtv;
	}
	void Render2D()
	{
		ML::Box2D src(0, 0, 32, 32);
		for (int y = 0; y < 4; ++y) {
			for (int x = 0; x < 5; ++x) {
				ML::Box2D draw(0, 0, 32, 32);
				draw.Offset(x * 32, y * 32);
				imgMapChip->Draw(draw, src);
			}
		}
	}
}
