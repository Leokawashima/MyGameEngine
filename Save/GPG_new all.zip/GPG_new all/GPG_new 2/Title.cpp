#include "MyGameMain.h"
namespace Title {

	int logoPosY;
	DG::Image::SP img;
	void Initialize()
	{
		img = DG::Image::Create("./data/image/Title.bmp");
		logoPosY = -270;
		gobj.bgColor = ML::Color(1, 0, 0, 1);
	}
	void Finalize()
	{
		img.reset();
	}
	TaskFlag UpDate()
	{
		auto inp = gobj.in[0]->GetState();
		logoPosY += 9;
		if (logoPosY > 0) { logoPosY = 0; }
		TaskFlag rtv = TaskFlag::Title;
		if (logoPosY >= 0) {
			if (true == inp.ST.down) {
				rtv = TaskFlag::Game;
			}
		}
		return rtv;
	}
	void Render2D()
	{
		ML::Box2D draw(0, 0, 480, 270);
		draw.Offset(0, logoPosY);
		ML::Box2D src(0, 0, 240, 135);
		img->Draw(draw, src);
	}
}
