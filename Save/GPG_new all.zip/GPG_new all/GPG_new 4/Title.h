#pragma once
#include "MyProgram.h"
class Title : public MyTask {
public:
	int logoPosY;
	DG::Image::SP img;
	Title();
	~Title();
	bool Initialize() override;
	MyTask* UpDate() override;
	void Render2D() override;
	void Render3D() override;
};
