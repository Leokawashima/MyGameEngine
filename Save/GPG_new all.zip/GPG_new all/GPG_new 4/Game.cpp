#include "AllTask.h"
//-------------------------------------------------------------------
Game::Game()
{
}
//-------------------------------------------------------------------
Game::~Game()
{
	this->meshBox1.reset();
	this->imgMapChip.reset();
}
//-------------------------------------------------------------------
bool Game::Initialize()
{
	//�V�[���؂�ւ��𕪂���₷�����邽�߂ɓ��ꂽ
	gobj.bgColor = ML::Color(1, 0, 1, 0);
	this->imgMapChip = DG::Image::Create("./data/image/MapChip01.bmp");
	//���b�V���̓ǂݍ���
	this->meshBox1 = DG::Mesh::Create_FromSOBFile("./data/mesh/box1.sob");
	//�J�����̐ݒ�
	//�v���W�F�N�V�����ϊ��̐ݒ�
	float cFOV = 35.0f * ML::PI / 180.0f;
	float cNearPlain = 10.0f;
	float cforePlain = 4000.0f;
	float cAspect = 16.0f / 9.0f;
	ML::Mat4x4 matP;
	matP.PerspectiveFovLH(cFOV, cAspect, cNearPlain, cforePlain);
	gobj.dgi->EffectState().param.matProjection = matP;
	//�r���[�ϊ��̐ݒ�
	ML::Vec3 cPos(400.0f, 1200.0f, -800.0f);
	ML::Vec3 cTarget(500.0f, 0.0f, 400.0f);
	ML::Vec3 cUp(0.0f, 1.0f, 0.0f);
	ML::Mat4x4 matV;
	matV.LookAtLH(cPos, cTarget, cUp);
	gobj.dgi->EffectState().param.matView = matV;
	return true;
}
//-------------------------------------------------------------------
MyTask* Game::UpDate()
{
	auto inp = gobj.in[0]->GetState();
	MyTask* rtv = this;//��肠�������݂̃^�X�N���w��
	if (true == inp.ST.down) {
		rtv = new Title();
	}
	return rtv;
}
//-----------------------------------------------------------------------------
void Game::Render2D()
{
	ML::Box2D src(0, 0, 32, 32);
	for (int y = 0; y < 4; ++y) {
		for (int x = 0; x < 5; ++x) {
			ML::Box2D draw(0, 0, 32, 32);
			draw.Offset(x * 32, y * 32);
			this->imgMapChip->Draw(draw, src);
		}
	}
}
//-----------------------------------------------------------------------------
void Game::Render3D()
{
	//���s�ړ��s��𐶐� //���[���h�ϊ���K�p����
	ML::Mat4x4 matT;
	matT.Translation(ML::Vec3(0, 0, 0));
	gobj.dgi->EffectState().param.matWorld = matT;
	this->meshBox1->Draw();
}
