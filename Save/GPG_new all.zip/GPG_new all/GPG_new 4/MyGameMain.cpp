#include "MyGameMain.h"
#include "AllTask.h"

void MyGameMain_Initalize()
{
	{
		XI::AnalogAxisKB ls = { DIK_LEFT, DIK_RIGHT, DIK_UP, DIK_DOWN };
		XI::AnalogAxisKB rs = { 0, 0, 0, 0 };
		XI::AnalogTriggerKB tg = { 0, 0 };
		XI::KeyDatas_KB key = {
		{ DIK_Z, XI::VGP::B1 },{ DIK_X, XI::VGP::B2 },{ DIK_S, XI::VGP::ST },
		};
		XI::KeyDatas_GP but = {
		{ XI::RGP::B01, XI::VGP::B1 },{ XI::RGP::B02, XI::VGP::B2 },
		{ XI::RGP::B08, XI::VGP::ST },
		};
		gobj.in[0] = XI::GamePad::CreateGP(0, but);
		auto kb = XI::GamePad::CreateKB(ls, rs, tg, key);
		XI::GamePad::Link(gobj.in[0], kb);
		gobj.actTask = nullptr;
		gobj.nextTask = new Title();
	}
}
void MyGameMain_Finalize()
{
	if (nullptr != gobj.actTask) {
		delete gobj.actTask;
		gobj.actTask = nullptr;
	}
}
void MyGameMain_Update()
{
	if (gobj.actTask != gobj.nextTask) {
		if (nullptr != gobj.actTask) {
			//�����s���̃^�X�N�̏I���������Ăт���
			delete gobj.actTask;
		}
		//���̃^�X�N�����s�Ώۂɂ���
		gobj.actTask = gobj.nextTask;
		if (false == gobj.actTask->Initialize()) {
			//�����Ɏ��s�������i�����I�ɂ͑Ή����������ǂ��j
		}
	}
	//�X�V
	if (nullptr != gobj.actTask)
	{
		gobj.nextTask = gobj.actTask->UpDate();
	}

}
void MyGameMain_Render2D()
{
	if (nullptr != gobj.actTask) {
		gobj.actTask->Render2D();
	}
}
void MyGameMain_Render3D()
{
	if (nullptr != gobj.actTask) {
		gobj.actTask->Render3D();
	}
}