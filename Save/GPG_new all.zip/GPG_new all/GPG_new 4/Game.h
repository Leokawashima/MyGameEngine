#pragma once
#include "MyProgram.h"
class Game : public MyTask {
public:
	DG::Image::SP imgMapChip;
	DG::Mesh::SP meshBox1;
	Game();
	~Game();
	bool Initialize() override;
	MyTask* UpDate() override;
	void Render2D() override;
	void Render3D() override;
};
