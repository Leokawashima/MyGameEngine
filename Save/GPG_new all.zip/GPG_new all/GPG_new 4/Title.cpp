#include "AllTask.h"
//-------------------------------------------------------------------
Title::Title()
{
}
//-------------------------------------------------------------------
bool Title::Initialize()
{
	this->img = DG::Image::Create("./data/image/Title.bmp");
	this->logoPosY = -270; //�^�C�g���摜�̏����ʒu����ʊO�ɔz�u����
	//�V�[���؂�ւ��𕪂���₷�����邽�߂ɓ��ꂽ
	gobj.bgColor = ML::Color(1, 0, 0, 1);
	return true;
}
//-------------------------------------------------------------------
MyTask* Title::UpDate()
{
	auto inp = gobj.in[0]->GetState();
	this->logoPosY += 9;
if (this->logoPosY > 0) { this->logoPosY = 0; }
MyTask* rtv = this;//��肠�������݂̃^�X�N���w��
if (this->logoPosY >= 0) {
	if (true == inp.ST.down) {
		rtv = new Game();
	}
}
return rtv;
}
//-------------------------------------------------------------------
void Title::Render2D()
{
	ML::Box2D draw(0, 0, 480, 270);
	draw.Offset(0, logoPosY);
	ML::Box2D src(0, 0, 240, 135);
	this->img->Draw(draw, src);
}
//-------------------------------------------------------------------
void Title::Render3D()
{
}
//-------------------------------------------------------------------
Title::~Title()
{
	this->img.reset();
}